// Matt Cooke
// 2073995
package cooke1and2;

public class Program1 {

	public static void main(String[] args) {
		System.out.println("My name is Matt Cooke");
		System.out.println("The default type for a floating point number is a double");
		System.out.println("Java int types are stored in 32 bits");
		System.out.println("float price = 1.29f;");
		System.out.println("Type Large can store extremely large integers");
		System.out.println("Java class names begin with an upper case character");
	}

}
